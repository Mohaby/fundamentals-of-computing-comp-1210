 /**.
*program to print studentInfo
*Activity 01
*@author Mohab Yousef - Comp1210
*08/24/2021
*/
  
public class StudentInfo
{
 /**.
 * prints StudentName,and any previous courses.
 * @param args Command line arguments - not used.
 */
   public static void main(String[]args) {
      System.out.println("Name: Mohab Yousef");
      System.out.println("Previous Computer Courses:");
      System.out.println("   Computer Fundmental 1213");
   }
}

 