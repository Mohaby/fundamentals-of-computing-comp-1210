/**. 
 *prints my life goals. 
 *Project 01
 * @author Mohab Yousef
 * @version 08/25/2021
 */
 
public class MyLifeGoals {

/**.
* Application that prints my life goals.
* @param args Command line arguments - not used.
    */
   public static void main(String[] args) {
   
   //print my first and last name
      System.out.println("Mohab Yousef");
      System.out.println("");
   //print my short term life goal
      System.out.println("My Short term goal is to finish the courses I got"
         + " this semseter with good grades,find a part time job"
         + " and learn some spanish");
   //print my medium term goal
      System.out.println("My Medium term goal is to find internship in"
         + " the school,learn some onlint coaching and do"
         + " my best to gradute after two years");
   //print my long term goal
      System.out.println("My long term goal is to find a good jop after I"
         + " gradute,move to Texas,try to get in another"
         + " major, then try to open my own buisness ");
   }
}
   