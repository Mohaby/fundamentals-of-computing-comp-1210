/**.  
 *
 * Project 10
 * @author Mohab Yousef
 * @version 11/10/2021
 */

import java.io.FileNotFoundException;
/**.
*MarketingCampaignPart2 
*/

public class AirTicketApp {
/**.
* @param args Command line arguments are used
* @throws FileNotFoundException just for you, WebCat. 
*/
   public static void main(String[] args) throws FileNotFoundException {
      if (args.length > 0)
      {
     
     
      
         String fileNameIn = args[0];
         AirTicketProcessor list = new AirTicketProcessor();
         list.readAirTicketFile(fileNameIn);
        
  
         System.out.print(list.generateReport());
        
         
         System.out.print(list.generateReportByFlightNum());
        
         
         System.out.print(list.generateReportByItinerary()); 
         

                        
      }
      else if (args.length == 0) {
         System.out.println("File name expected as command line argument."
                           + "\nProgram ending.");

      }  
   }
}